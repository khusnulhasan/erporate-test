<?php

class Api extends CI_Controller{

	public function index()
	{
		$data['judul'] = 'Dokumentasi API';
		$this->load->view('templates/header', $data);
		$this->load->view('api/index');
		$this->load->view('templates/footer');
	}
}