<?php 


class Produk extends CI_Controller{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Produk_model');
	}

	public function index()
	{
		$data['judul'] = 'Produk';
		$data['produk'] = $this->Produk_model->getAllProduk();

		if ($this->input->post('keyword')) {
			$data['produk'] = $this->Produk_model->cariDataProduk();
		}

		if ($this->input->post('filter')) {
			$data['produk'] = $this->Produk_model->filterProduk();
		}

		$this->load->view('templates/header', $data);
		$this->load->view('produk/index', $data);
		$this->load->view('templates/footer');
	}

	public function detail($id)
	{
		$data['judul'] = 'Detail Produk';
		$data['produk'] = $this->Produk_model->getProdukById($id);
		$this->load->view('templates/header', $data);
		$this->load->view('produk/detail', $data);
		$this->load->view('templates/footer');
	}	

	public function tambah()
	{
		$data['judul'] = 'Tambah Produk';
		$this->load->view('templates/header', $data);
		$this->load->view('produk/tambah');
		$this->load->view('templates/footer');
	}

	public function tambahData()
	{

		$this->Produk_model->tambahDataProduk();
		redirect('produk');
	}

	public function getData()
	{
		$id = $this->input->get('id');
		if ($id === null) {
			$produk = $this->Produk_model->getAllProdukJson();

		}else{
			$produk = $this->Produk_model->getAllProdukJson($id);
		}


		if($produk){
			echo json_encode($produk);
		}else{
			echo "data tidak tersedia";
		}
	}

}