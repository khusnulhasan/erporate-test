<?php

class Produk_model extends CI_model {

	public function getAllProduk()
	{
		$query = $this->db->get('produk');
		return $query->result_array();
	}

	public function getProdukById($id)
	{
		$query = $this->db->get_where('produk', ['id' => $id])->row_array();
		return $query;
	}


	public function getAllProdukJson($id = null)
	{

		if ($id === null) {
			$query = $this->db->get('produk')->result_array();
			return $query;
		}else{
			$query = $this->db->get_where('produk', ['id' => $id])->result_array();
			return $query;
		}

	}

	public function tambahDataProduk()
	{
		$gambar = $_FILES['gambar']['name'];
		$time  = time();
		$explode_gambar = explode('.', $gambar);
		$extension_gambar = end($explode_gambar);
		$path = basename($explode_gambar[0]. $time . '.' . $extension_gambar);

		$data = [
			"judul" => $this->input->post('judul'),
			"gambar" => $path,
			"kategori" => $this->input->post('kategori'),
			"deskripsi" =>$this->input->post('deskripsi')
		];


		$config['upload_path'] ='./assets/image';
		$config['allowed_types'] = 'jpeg|jpg|png';
		$config['file_name'] = $path;


		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('gambar'))
		{
			echo "gagal upload"; die();
		}

		$this->db->insert('produk', $data);

	}

	public function cariDataProduk()
	{
		$keyword = $this->input->post('keyword');
		$this->db->like('judul', $keyword);
		return $this->db->get('produk')->result_array();
	}

	public function filterProduk()
	{
		$filter = $this->input->post('filter');
		$this->db->like('kategori', $filter);
		return $this->db->get('produk')->result_array();
	}
}