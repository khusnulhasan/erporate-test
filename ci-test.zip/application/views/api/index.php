<div class="container mt-4">
	<h1>DOKUMENTASI API</h1>
	<br>
	
	Untuk mengambil semua data => <b>http://localhost/ci-app/produk/getdata</b>

	<br><hr>
	
	Untuk mengambil semua data berdasarkan id, maka tambahkan id => <b>http://localhost/ci-app/produk/getdata?id=</b>
	<br><br>
	example : saya ingin mengambil id 24, maka => <b>http://localhost/ci-app/produk/getdata?id=24</b>

	<br><br>

	<b>NB :</b> Maaf saya cuma membuatnya bisa ambil data, dan pagination juga belum saya buat


</div>