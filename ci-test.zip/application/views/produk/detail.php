<div class="container mt-5">
	<div class="row mt-2">
			<div class="col-lg-3">
				<div class="card">
					<img src="<?= base_url(); ?>assets/image/<?= $produk['gambar'] ?>" class="card-img-top img-fluid" style="height: 200px;">
					<div class="card-body">
						<h5 class="card-title"><?= $produk['judul'] ?></h5>
						<span class="card-title">Kategori : <?= $produk['kategori'] ?></span>
						<br>
						<p class="card-text">Deskripsi : <?= $produk['deskripsi'] ?></p>
						<a href="<?= base_url(); ?>produk" class="btn btn-primary">Kembali</a>
					</div>
				</div>
			</div>


	</div>
</div>