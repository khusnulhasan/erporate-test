<div class="container mt-4">

	<div class="row">
		<div class="col-lg-6">
			<h3>Tambah Data</h3>
			<!-- <button class="btn btn-primary" type="submit" id="submitData" data-toggle="modal" data-target="#tambahData">Tambah Data</button> -->
			<!-- <input type="submit" class="btn btn-primary" value="Tambah Data"> -->
			<a href="<?= base_url(); ?>produk/tambah" class="btn btn-primary">Tambah Data</a>
		</div>
	</div>

	<div class="row mt-4">
		<div class="col-lg-6">
			<form action="" method="post">
				<div class="input-group mb-3">
					<input type="text" class="form-control" placeholder="Cari Produk..." name="keyword" id="keyword" autocomplete="off">
					<div class="input-group-append">
						<button class="btn btn-primary" type="submit" id="tombolCari">Cari</button>
					</div>
				</div>
			</form>
		</div>
	</div>

	<div class="row mt-4">
		<div class="col-lg-6">
			<form action="" method="post">
				<div class="input-group mb-3">
					<div class="form-group">
						<label for="filter">Filter</label>
						<select class="form-control" name="filter">
							<option value="">Semua Produk</option>
							<option value="sate">Sate</option>
							<option value="nasi">Nasi</option>
							<option value="snack">Snack</option>
							<option value="cemilan">Cemilan</option>
						</select>
					<button class="btn btn-primary" type="submit" id="tombolCari">Filter</button>
					</div>
				</div>

			</form>
		</div>
	</div>	

	<div class="row mt-2">
		<div class="col-lg-6">
			<h3>Daftar Menu</h3>
		</div>
	</div>

	<div class="row mt-2">
		<?php foreach ($produk as $key): ?>
			
			<div class="col-lg-3">
				<div class="card">
					<img src="<?= base_url(); ?>assets/image/<?= $key['gambar']; ?>" class="card-img-top img-fluid" style="height: 200px;">
					<div class="card-body">
						<h5 class="card-title"><?= $key['judul']; ?></h5>
						<a href="<?= base_url(); ?>produk/detail/<?= $key['id']; ?>" class="btn btn-primary">Detail</a>
					</div>
				</div>
			</div>

		<?php endforeach ?>

	</div>

</div>



<!-- Modal -->
<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<?php echo form_open_multipart('produk/tambah');?>
				<div class="form-group">
					<label for="nama">Nama</label>
					<input type="text" class="form-control" id="nama" name="nama">
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" class="form-control" id="email" name="email">
				</div>
				<div class="form-group">
					<label for="nim">NIM</label>
					<input type="number" class="form-control" id="nim" name="nim">
				</div>
				<div class="form-group">
					<label for="jurusan">Upload Gambar</label>
					<input type="file" class="form-control-file" id="jurusan" name="jurusan">
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Tambah Data</button>
			</div>
		</form>
	</div>
</div>
</div>