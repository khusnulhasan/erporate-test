<div class="container mt-5">

	<?php echo form_open_multipart('produk/tambahData');?>
	<div class="form-group">
		<label for="judul">Judul</label>
		<input type="text" class="form-control" id="judul" name="judul">
	</div>
	<div class="form-group">
		<label for="gambar">Upload Gambar</label>
		<input type="file" class="form-control-file" id="gambar" name="gambar">
	</div>
	<div class="form-group">
		<label for="kategori">Kategori</label>
		<select class="form-control" id="kategori" name="kategori">
			<option value="sate">Sate</option>
			<option value="nasi">Nasi</option>
			<option value="snack">Snack</option>
			<option value="cemilan">Cemilan</option>
		</select>
	</div>

	<div class="form-group">
		<label for="deskripsi">Deskripsi</label>
		<textarea class="form-control" id="deskripsi" rows="3" name="deskripsi"></textarea>
	</div>

	<button type="submit" class="btn btn-primary">Tambah Data</button>

</form>

</div>